import { PRODUCT_LIST } from "../Redux/Constant"


export const productData = () => {
    
      return{
        type:PRODUCT_LIST,
        data:"Greet"
      }
} 