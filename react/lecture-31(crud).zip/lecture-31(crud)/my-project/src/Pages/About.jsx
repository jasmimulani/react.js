import React from 'react'
import Navbar from '../Componets/Navbar'


const About = () => {
  return (
    <div>
      <Navbar/>
                  <h1 className='text-3xl font-normal text-center'>This is About Page</h1>

    </div>
  )
}

export default About
