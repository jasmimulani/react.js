import React from 'react'
// import Navbar from '../Componets/Navbar'

const Home = () => {
  return (
    <div>
      {/* <Navbar/> */}
      <h1 className='text-2xl font-bold text-center'> this is home page</h1>
    </div>
  )
}

export default Home
