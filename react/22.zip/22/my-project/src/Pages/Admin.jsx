import React from 'react'

const Admin = () => {
  return (
    <div>
      <h1> this is admin pag</h1>
    </div>
  )
}

export default Admin
