import React from 'react'
// import Navbar from '../Componets/Navbar'

const Error404 = () => {
  return (
    <div>
      {/* <Navbar/> */}
      <h1 className='text-2xl font-bold text-center'> Error 404</h1>
    </div>
  )
}

export default Error404
