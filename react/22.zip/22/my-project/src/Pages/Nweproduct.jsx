import React from 'react'

const Nweproduct = () => {
  return (
    <div>
      <h1> this is new product page</h1>
    </div>
  )
}

export default Nweproduct
