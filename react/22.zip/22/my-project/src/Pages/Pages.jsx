import React from 'react'
// import Navbar from '../Componets/Navbar'

const Pages = () => {
  return (
    <div>
      {/* <Navbar/> */}
      <h1 className='text-2xl font-bold text-center'> this is  page</h1>
    </div>
  )
}

export default Pages
