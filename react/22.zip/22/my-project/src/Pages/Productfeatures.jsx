import React from 'react'

const Productfeatures = () => {
  return (
    <div>
      <h1> this is Features page</h1>
    </div>
  )
}

export default Productfeatures
